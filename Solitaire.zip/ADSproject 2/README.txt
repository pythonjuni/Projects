SOLITAIRE GAME:

-> A Solitaire game in python on the console using stacks and queues.
-> Used various types of data structures - Mainly Stacks and Queues 
-> Using Pygame Library for the GUI spin-up


OTHER:

- Card & Deck Class are on 'Card.py' file
- Main Structure is on 'Stacks.py' file
- The Master File is main.py


HOW TO RUN THE GAME:

1. Run main.py
2. Follow terminal indications
3. Start Playing

Characteristics / functions created:

- Made a deck of cards and then we made a stack of 21 cards that are hidden
- Made a queue of the remaining cards
- Made 7 stacks of cards that are visible
- Function that prints the board
- Function that lets the user draw a card from the queue
- Function that lets the user move a card from one stack to another
- Function that lets the user add a card to a set
- Fucntion that opens a card from a hidden hidden stack
    - Created a max and count dictionary seeing how one stack can only pop a card from the hidden stack a set amount of time
- Function that lets the user quit the game
- Function that lets the user resume the game
- Function that lets the user win the game
- Function that lets the user restart the game
- Function that lets the user save the game
- Function that lets the user load the game
- Function that lets the user play the game

Forward we would also like to work on making a GUI seeing how solitaire is a difficult game to represent only on terminal. 
If you want to you can run the board_solitaire.py to see how we would like it to work :) 
Also the logic could be simplified by having a function called valid_move() which can check the move for options 1. and 2.



