from stacks import *
from Card import *
import random

#print the board
def print_board(list_of_stacks):
    for i in range(len(list_of_stacks)):
        print(f"{i + 1}.)")
        stack = list_of_stacks[i]
        node = stack.top
        while node:
            card = node.value
            print(f'{card.symbol}{card.number}')
            print()
            node = node.next

#place a card
def place_card(card, stack):
    stack.push(card)

def draw_card(qdeck, lists):
    card = qdeck.dequeue()
    print("You have drawn", card.symbol, card.number)
    place = input(f"\nDo you want to place {card.symbol}{card.number} ? Y/N ")
    if place == 'y':
        print_board(lists)
        stack = int(input(f'Which stack would you like to add {card.symbol}{card.number} to? '))
        place_card(card, lists[stack - 1])
    else:
        qdeck.enqueue(card)

#append the values to an array
def stack_to_list(stack):
    array = [0] * stack.length
    i = 0
    while stack.length > 0:
         array[i] = stack.pop()
         i += 1
    return array

def valid_move(card, stack):
    pass
      
def move_from_stack(stacks, hidden, count, max):
        start = int(input("Choose from what stack you want to move >> ")) - 1
        end = int(input("Choose what stack to move to >> ")) - 1
        #So we need to invert the 'start' stack because the last element in this stack will be added to end. last element in start
            # will be connected to top in stacks[end]. And the stack as a whole will have end.top as the top
        stack = stacks[start]
        if stack.top is None:
            return count, hidden
        array = stack_to_list(stacks[start])
        #now we append the values in the array to the 'end' stack backwards
        index = -len(array) + 1
        while index <= 0:
            stacks[end].push(array[index])
            index += 1
        #fill in the empty stacks
        if stack.top != None:
            return count, hidden
        else:
            if count[start] < max[start]:
                (stacks[start]).push(hidden.pop())
                count[start] += 1
                return count, hidden
            else:
                print("This stack doesnt have anymore hidden cards to pull")
                return count, hidden
'''
def open_from_hidden(stacks, hidden, count, max):
    inp = int(input("Choose an empty stack to flip up a new card >> "))
    stack = stacks[inp - 1]
    if stack.top != None:
        print("Stack is not empty")
        return count, hidden
    else:
        if count[inp - 1] < max[inp - 1]:
            (stacks[inp - 1]).push(hidden.pop())
            count[inp-1] += 1
            return count, hidden
        else:
            print("This stack doesnt have anymore hidden cards to pull")
            return count, hidden
'''   
        
def suit_collector(stacks, suits):
    inp = int(input("\nChoose a stack >> ")) - 1
    stack = stacks[inp]
    if stack.top == None:
        print("Stack is empty")
    card = (stack.top).value
    char = card.symbol
    print(char)
    if char == 'H':
        suit = suits[0]
        right = (suit.top.value.symbol, suit.top.value.number)
        if stack.top.value == suit.top.value:
            stack.pop()
            suit.pop()
        else:
            print(f"Not the right card, only {right} can be appended")
    elif char == 'C':
        suit = suits[1]
        right = (suit.top.value.symbol, suit.top.value.number)
        if stack.top.value == suit.top.value:
            stack.pop()
            suit.pop()
        else:
            print(f"Not the right card, only {right} can be appended")
    elif char == 'S':
        suit = suits[2]
        right = (suit.top.value.symbol, suit.top.value.number)
        if stack.top.value == suits[2].top.value:
            stack.pop()
            suit.pop()
        else:
            print(f"Not the right card, only {right} can be appended")
    elif char == 'D':
        suit = suits[3]
        right = (suit.top.value.symbol, suit.top.value.number)
        if stack.top.value == suit.top.value:
            stack.pop()
            suit.pop()
        else:
            print(f"Not the right card, only {right} can be appended")
    

def main():
    #print(x)
    '''
    x = Deck()
    x.shuffle()

    deck = Stack()
    for i in range(52):
        deck.push(x.deal(1))
'''

    cardList = []
    cardSymbols = ['C', 'H', 'S', 'D']
    for symbol in cardSymbols:
        for o in range(0, 13):
            cardList.append(Card(symbol, o + 1))
    
    hearts = Stack()
    clubs = Stack()
    spades = Stack()
    diamonds = Stack()  
    
    cardList.reverse()
    #printCardValues(cardList)
    for i in range(0, 13):
        diamonds.push(cardList[i])
    for i in range(13, 26):
        spades.push(cardList[i])
    for i in range(26, 39):
        hearts.push(cardList[i])
    for i in range(39,51):
        clubs.push(cardList[i])
    suits = [hearts, clubs, spades, diamonds]  

    
    
    random.shuffle(cardList)
    deck = Stack()

    for i in range(len(cardList)):
        value = cardList[i]
        deck.push(value)


    #make and deal the beginning stacks
    one = Stack()
    two = Stack()
    three = Stack()
    four = Stack()
    five = Stack()
    six = Stack()
    seven = Stack()

    one.push(deck.pop())
    two.push(deck.pop())
    three.push(deck.pop())
    four.push(deck.pop())
    five.push(deck.pop())
    six.push(deck.pop())
    seven.push(deck.pop())

    #add them to a list
    stacks = [one, two, three, four, five, six, seven]

    #make a stack for the 21 cards that are 'hidden'
    #these will be appended to a empty stack (stack.top = None)
    hidden = Stack()
    for i in range(21):
        hidden.push(deck.pop())
    
    #make sure that stack[0] has no turns to open up card from hidden
    #stack[1] can do it one time etc..
    max = {}
    count = {}
    
    for i in range(len(stacks)):
        #the max of stack 1 is 0 etc
        max[i] = i
        count[i] = 0
    
    #make a queue out of the remaining cards
    #this will be where the user chooses from
    qdeck = Queue()
    while deck.length != 0:
        qdeck.enqueue(deck.pop())
    
    #main game loop

    running = True
    '''
    print(hidden.length)
    print()
    print(qdeck.length)
    print()
    for i in range(len(stacks)):
        print(stacks[i].length)
    print()
    '''
    while running == True:
        #uncomment this to see that the objects are updating as you go
        print_board(stacks)
        
        '''
        print(qdeck.length)
        print()
        print(hidden.length)
        print()
        for i in range(len(stacks)):
            print(stacks[i].length)
        print()
        '''
        
        choice = int(input("1. Draw a card\n2. Move from one stack to another\n3. Add a card to a set\n>> "))
        if choice == 1:
            draw_card(qdeck, stacks)
        elif choice == 2:
            count, hidden = move_from_stack(stacks, hidden, count, max)
        elif  choice == 3:
            suit_collector(stacks, suits)
        else:
            choice = int(input("Press 1 to quit\nPress 2 to resume\n>> "))
            if choice == 1:
                running = False

        if hearts.length == 0 and spades.length == 0 and clubs.length == 0 and diamonds.legth == 0:
            print("\nCongrats you won a game of solitaire!")
            running = False


main()
        








