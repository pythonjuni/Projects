import random

class Card:
    def __init__(self, symbol, number):
        self.symbol = symbol
        self.number = number
        if symbol == 'H' or symbol == 'D':
            self.color = 'red'
        else:
            self.color = 'black'

def printCardValues(cardList):
    for card in cardList:
        print(f'{card.symbol}{card.number}{card.color}')
        
cardList = []
cardSymbols = ['C', 'H', 'S', 'D']
for symbol in cardSymbols:
    for o in range(0, 13):
        cardList.append(Card(symbol, o + 1))
        
printCardValues(cardList)