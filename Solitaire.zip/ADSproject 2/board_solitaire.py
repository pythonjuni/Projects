
from stacks import *
import pygame
import sys
import imageio as iio
from pydealer import *

#import the pictures
clubs = pygame.image.load("img/clubs.png")
diamonds = pygame.image.load("img/diamond.png")
hearts = pygame.image.load("img/hearts.png")
spades = pygame.image.load("img/spades.png")

#resize images
new_clubs = pygame.transform.scale(clubs, (250, 400))
new_diamonds = pygame.transform.scale(diamonds, (250, 400))
new_hearts = pygame.transform.scale(hearts, (250, 400))
new_spades = pygame.transform.scale(spades, (250, 400))


color = (119, 221, 119) #background
rec_color = (0,110,51) #change
     
    

pygame.init()

w = 1360
h = 840
screen = pygame.display.set_mode((w,h)) #41


#main game loop

running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    
    #set title for pygame window 
    caption = 'solitaire'
    pygame.display.set_caption(caption)
    
    #fill with background
    screen.fill(color)
    
    #deck position
    w_c = 50
    h_c = 50
    pygame.draw.rect(screen, rec_color, (0, 0, 160, h))
    pygame.draw.rect(screen, (0,0,0), (20, 20, 120, 180), 4, 2)
    
    #main card display
    
    #first is the left corner, second is from the roof,
    # I want 20 space between each of the so the formula will be
    #position = 180 + 20*i width is 120 so increment with 120 each time
    #and the length is 180
    '''
    for i in range(0, 7):
        pygame.draw.rect(screen, (0,0,0), (180 + 120*i + 20*i, 20, 120, 180), 4, 2)
    '''
    
    #the suits holders on the side
    for i in range(0, 4):
        pygame.draw.rect(screen, (0,0,0), (w - 120 - 20, 180*i + 20*i + 20, 120, 180), 4, 2)
    
    
    for i in range(1, 8):
        pygame.draw.rect(screen, (0,0,0), (125*i + 20*i + 80, 20, w_c, h_c), 2, 2)
        for j in range(1, i):
            pygame.draw.rect(screen, (0,0,0), (125*i + 20*i + 80, 50*j + 20, w_c, h_c), 2, 2)
    
    screen.blit(new_clubs, [1155, 10])
    screen.blit(new_hearts, [1155, 200 + 5*5])
    screen.blit(new_diamonds, [1155, 180*2 + 5*10])
    screen.blit(new_spades, [1155, 180*3 + 5*15])
    
    pygame.display.update()


pygame.quit()


